package ui;

import javax.swing.*;

public abstract class Panel extends JPanel {
    public abstract Class getEntityClass();

    protected String getEntityName() {
        // Java metaprogramming, obtengo el método de la clase si existe, y en dicho caso lo llamo
        try {
            java.lang.reflect.Method method = getEntityClass().getMethod("getEntityName");
            return (String) method.invoke(null);
        } catch (Exception e) {
            // Si no existe el método, devuelvo nada
            return "";
        }
    }

    protected String getEntityNamePlural() {
        // Java metaprogramming, obtengo el método de la clase si existe, y en dicho caso lo llamo
        try {
            java.lang.reflect.Method method = getEntityClass().getMethod("getEntityNamePlural");
            return (String) method.invoke(null);
        } catch (Exception e) {
            // Si no existe el método, devuelvo nada
            return "";
        }
    }
}
