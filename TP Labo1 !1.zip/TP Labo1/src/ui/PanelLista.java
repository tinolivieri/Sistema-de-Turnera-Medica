package ui;

import Controlador.Controlador;
import Entidades.entidad;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.util.List;

public abstract class PanelLista extends Panel {
    protected Controlador controlador;
    protected JButton btnNuevo;
    protected JButton btnModificar;
    protected JButton btnEliminar;
    protected JButton btnVolver;
    protected JPanel botones;
    protected JList entityList;
    protected JScrollPane scrollPane;
    protected DefaultListModel<entidad> listModel;

    public PanelLista(Controlador controlador) {
        this.controlador = controlador;
        controlador.getFramePrincipal().setTitulo("Gestión de " + this.getEntityNamePlural());

        setLayout(new BorderLayout());

        construirLista();
        construirBotones();

        add(scrollPane, BorderLayout.CENTER);
        add(botones, BorderLayout.SOUTH);
    }

    protected void construirLista() {
        entityList = new JList();

        listModel = new DefaultListModel<>();
        for (entidad entidad : this.listarEntidades()) {
            listModel.addElement(entidad);
        }
        entityList.setModel(listModel);

        entityList.addListSelectionListener(e -> {
            if (entityList.getSelectedValue() == null) {
                btnModificar.setEnabled(false);
                btnEliminar.setEnabled(false);
            } else {
                btnModificar.setEnabled(true);
                btnEliminar.setEnabled(true);
            }
        });

        scrollPane = new JScrollPane(entityList);
    }

    protected <T extends entidad> List<T> listarEntidades() {
        return controlador.listarEntidades(this.getEntityClass());
    }

    protected void construirBotones() {
        botones = new JPanel();

        btnNuevo = new JButton("Nuevo " + this.getEntityName());
        btnNuevo.addActionListener(e -> accionNuevo(e));
        botones.add(btnNuevo);

        btnModificar = new JButton("Modificar " + this.getEntityName());
        btnModificar.setEnabled(false);
        btnModificar.addActionListener(e -> accionModificar(e));
        botones.add(btnModificar);

        btnEliminar = new JButton("Eliminar " + this.getEntityName());
        btnEliminar.setEnabled(false);
        btnEliminar.addActionListener(e -> accionEliminar(e));
        botones.add(btnEliminar);

        btnVolver = new JButton("Volver");
        btnVolver.addActionListener(e -> accionVolver(e));
        botones.add(btnVolver);
    }

    protected void accionNuevo(ActionEvent _event) {
        controlador.panelNuevaEntidad(getEntityClass());
    }

    protected void accionModificar(ActionEvent _event) {
        controlador.panelModificarEntidad((entidad) entityList.getSelectedValue());
    }

    protected void accionEliminar(ActionEvent _event) {
        if (controlador.eliminarEntidad((entidad) entityList.getSelectedValue())) {
            listModel.removeElement(entityList.getSelectedValue());
        }
    }

    protected void accionVolver(ActionEvent _event) {
        controlador.visualizarMenuPrincipal();
    }
}
