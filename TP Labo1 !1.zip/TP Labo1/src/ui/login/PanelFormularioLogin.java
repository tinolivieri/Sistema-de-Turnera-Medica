package ui.login;

import Controlador.Controlador;
import Entidades.entidad;
import ui.PanelFormulario;
import Util.UI;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;

public class PanelFormularioLogin extends PanelFormulario {
    private JLabel lblEmail;
    private JLabel lblPassword;
    private JTextField txtEmail;
    private JPasswordField txtPassword;

    public PanelFormularioLogin(Controlador controlador, entidad entidad) {
        this.controlador = controlador;
        this.entidad = entidad;

        controlador.getFramePrincipal().setTitulo("Login");

        setLayout(new BorderLayout());

        add(construirFormulario(), BorderLayout.CENTER);

        add(construirBotones(), BorderLayout.SOUTH);
    }

    @Override
    protected JPanel construirFormulario() {
        JPanel form = new JPanel();
        form.setLayout(new GridLayout(0, 2, 10, 10));

        lblEmail = UI.crearLabel("Mail: ");
        lblPassword = UI.crearLabel("Contraseña: ");

        txtEmail = UI.construirTextField("");
        txtPassword = new JPasswordField();

        form.add(lblEmail);
        form.add(txtEmail);
        form.add(lblPassword);
        form.add(txtPassword);

        return form;
    }

    @Override
    protected String labelBotonGuardar() {
        return "Ingresar";
    }

    protected void accionGuardar(ActionEvent _event) {
        if (controlador.validarLogin(txtEmail.getText(), txtPassword.getText())) {
            controlador.visualizarMenuPrincipal();
        } else {
            controlador.getFramePrincipal().visualizarError("Mail o Contraseña inválidos");
        }
    }

    @Override
    protected void accionCancelar(ActionEvent _event) {

    }

    @Override
    public Class getEntityClass() {
        return null;
    }
}
