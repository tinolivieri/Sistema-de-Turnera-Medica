package ui;

import Controlador.Controlador;
import Entidades.admin;
import javax.swing.*;
import java.awt.*;
import java.awt.event.WindowEvent;
import java.util.ArrayList;

public class FramePrincipal extends JFrame {
    private Controlador controlador;

    public FramePrincipal(Controlador controlador) {
        super("Consultorio V1.0");

        this.controlador = controlador;

        getContentPane().setLayout(new GridLayout(1, 1));
        setSize(1920, 1080);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        setVisible(true);
    }

    public void construirMenu() {
        setJMenuBar(crearMenu());
    }

    public void setTitulo(String titulo) {
        if (titulo != null) {
            setTitle("Consultorio V1.0 - " + titulo);
        } else {
            setTitle("Consultorio V1.0");
        }
    }

    public void pantallaPrincipal() {
        setTitle(null);

        JPanel panel = new JPanel();

        ArrayList<JButton> botones = new ArrayList<>();
        if (controlador.getUsuario() instanceof admin) {
            JButton btnGestionarAdministradores = new JButton("Gestionar administradores");
            botones.add(btnGestionarAdministradores);
            btnGestionarAdministradores.addActionListener(e -> controlador.visualizarAdministradores());

            JButton btnGestionarDoctores = new JButton("Gestionar doctores");
            botones.add(btnGestionarDoctores);
            btnGestionarDoctores.addActionListener(e -> controlador.visualizarDoctores());

        }

        JButton btnGestionarTurnos = new JButton("Gestionar turnos");
        botones.add(btnGestionarTurnos);
        btnGestionarTurnos.addActionListener(e -> controlador.visualizarTurnos());

        JButton btnSalir = new JButton("Salir");
        botones.add(btnSalir);
        btnSalir.addActionListener(e -> dispatchEvent(new WindowEvent(this, WindowEvent.WINDOW_CLOSING)));

        panel.setLayout(new GridLayout(botones.size(), 1));

        for (JButton boton : botones) {
            boton.setFont(new Font("Arial", Font.PLAIN, 20));
            panel.add(boton);
        }

        setPanel(panel);
    }

    public void setPanel(JPanel panel) {
        GridLayout constraints = new GridLayout(1, 1);

        getContentPane().removeAll();
        getContentPane().add(panel, constraints);
        getContentPane().revalidate();
    }

    private JMenuBar crearMenu() {
        JMenuBar menuBar = new JMenuBar();

        JMenu mnuArchivo = new JMenu("Archivo");
        mnuArchivo.setMnemonic('A');
        if (controlador.getUsuario() instanceof admin) {
            JMenuItem mnuAdministradores = new JMenuItem("Gestionar Administradores", 'A');
            JMenuItem mnuDoctores = new JMenuItem("Gestionar Medicos", 'M');

            mnuAdministradores.addActionListener(e -> controlador.visualizarAdministradores());
            mnuDoctores.addActionListener(e -> controlador.visualizarDoctores());

            mnuArchivo.add(mnuDoctores);
            mnuArchivo.add(mnuAdministradores);
        }
        JMenuItem mnuTurnos = new JMenuItem("Gestionar Turnos", 'T');
        JMenuItem mnuSalir = new JMenuItem("Salir", 'S');

        mnuTurnos.addActionListener(e -> controlador.visualizarTurnos());
        mnuSalir.addActionListener(e -> salir());

        mnuArchivo.add(mnuTurnos);
        mnuArchivo.addSeparator();
        mnuArchivo.add(mnuSalir);

        menuBar.add(mnuArchivo);

        return menuBar;
    }

    public void visualizarInformacion(String mensaje) {
        JOptionPane.showMessageDialog(this, mensaje, "Información", JOptionPane.INFORMATION_MESSAGE);
    }

    public void visualizarError(String error) {
        JOptionPane.showMessageDialog(this, error, "Error", JOptionPane.ERROR_MESSAGE);
    }

    public void visualizarError(Exception error) {
        JOptionPane.showMessageDialog(this, error.getLocalizedMessage(), "Error", JOptionPane.ERROR_MESSAGE);
    }

    public<T extends JPanel> void visualizarPanel(T panel) {
        try {
            setPanel(panel);
        } catch (RuntimeException e) {
            visualizarError(e);
        }
    }

    public void salir() {
        dispatchEvent(new WindowEvent(this, WindowEvent.WINDOW_CLOSING));
    }
}
