package ui.turnos;

import Controlador.Controlador;
import Entidades.admin;
import Entidades.entidad;
import Entidades.turno;
import ui.PanelLista;

import javax.swing.*;
import java.util.List;

public class PanelTurnos extends PanelLista {
    public PanelTurnos(Controlador controlador) {
        super(controlador);
    }

    protected <T extends entidad> List<T> listarEntidades() {
        if (controlador.getUsuario() instanceof admin) {
            return controlador.listarEntidades(this.getEntityClass(), "fecha");
        } else {
            return controlador.listarEntidades(this.getEntityClass(), controlador.getUsuario());
        }
    }

    @Override
    public Class getEntityClass() {
        return turno.class;
    }

    @Override
    protected void construirBotones() {
        if (controlador.getUsuario() instanceof admin) {
            super.construirBotones();
        } else {
            botones = new JPanel();

            btnVolver = new JButton("Volver");
            btnVolver.addActionListener(e -> accionVolver(e));
            botones.add(btnVolver);
        }
    }
}
