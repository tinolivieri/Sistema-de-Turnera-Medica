package ui.turnos;

import Controlador.Controlador;
import Entidades.*;
import ui.PanelFormulario;
import Util.UI;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class PanelFormularioTurno extends PanelFormulario {
    private JLabel lblId;
    private JLabel lblDoctor;
    private JLabel lblFecha;

    private JTextField txtId;
    private JList<medico> lstDoctores;
    private DefaultListModel<medico> listDoctoresModel;
    private JTextField txtFecha;

    public PanelFormularioTurno(Controlador controlador, entidad entidad) {
        super(controlador, entidad);
    }

    protected JPanel construirFormulario() {
        JPanel form = new JPanel();
        form.setLayout(new GridLayout(0, 2, 10, 10));

        lblId = UI.crearLabel("ID: ");
        lblDoctor = UI.crearLabel("Doctor: ");
        lblFecha = UI.crearLabel("Fecha: (yyyy/mm/dd hh:mm) ");

        turno turno = (turno)entidad;

        txtId = UI.construirTextField(String.valueOf(turno.getId()));
        txtId.setEditable(false);
        construirListaDoctores();
        if (turno.getFecha() != null) {
            txtFecha = UI.construirTextField(turno.getFecha().format(DateTimeFormatter.ofPattern(turno.FORMATO_FECHA)));
        } else {
            txtFecha = UI.construirTextField("");
        }

        if (!turno.isNew()) {
            form.add(lblId);
            form.add(txtId);
        }
        form.add(lblDoctor);
        form.add(lstDoctores);
        form.add(lblFecha);
        form.add(txtFecha);

        return form;
    }

    public void construirListaDoctores() {
        lstDoctores = new JList();

        actualizarListaDoctores();
    }

    public void actualizarListaDoctores() {
        if (lstDoctores == null) return;

        listDoctoresModel = new DefaultListModel<>();

        // Obtener la lista completa de médicos sin depender de consultorios
        for (entidad entidad : controlador.listarEntidades(medico.class)) {
            listDoctoresModel.addElement((medico) entidad);
        }

        lstDoctores.setModel(listDoctoresModel);

        turno turno = (turno)entidad;
        if (turno.getMedico() != null) {
            lstDoctores.setSelectedValue(turno.getMedico(), true);
        }
    }


    protected void accionGuardar(ActionEvent _event) {
        turno turno = (turno)entidad;
        turno.setMedico(lstDoctores.getSelectedValue());
        try {
            turno.setFecha(LocalDateTime.parse(txtFecha.getText(), DateTimeFormatter.ofPattern(turno.FORMATO_FECHA)));
        } catch (Exception e) {
            controlador.getFramePrincipal().visualizarError("Fecha inválida: " + e.getMessage());
            return;
        }

        if (turno.isNew()) {
            if (controlador.insertarEntidad(turno)) {
                controlador.visualizarTurnos();
            }
        } else {
            if (controlador.modificarEntidad(turno)) {
                controlador.visualizarTurnos();
            }
        }
    }

    protected void accionCancelar(ActionEvent _event) {
        controlador.visualizarTurnos();
    }

    @Override
    public Class getEntityClass() {
        return turno.class;
    }
}
