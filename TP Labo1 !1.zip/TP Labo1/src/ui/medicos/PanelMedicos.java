package ui.medicos;

import Entidades.medico;
import Controlador.Controlador;
import ui.PanelLista;

public class PanelMedicos extends PanelLista {
    public PanelMedicos(Controlador controlador) {
        super(controlador);
    }

    @Override
    public Class getEntityClass() { return medico.class;
    }

}