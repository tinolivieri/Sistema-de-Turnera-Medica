package ui.medicos;

import Controlador.Controlador;
import Entidades.medico;
import Entidades.entidad;
import ui.PanelFormulario;
import Util.UI;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.math.BigDecimal;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.util.Locale;

public class PanelFormularioMedicos extends PanelFormulario {
    private JLabel lblId;
    private JLabel lblEmail;
    private JLabel lblPassword;
    private JLabel lblLegajo;
    private JLabel lblNombre;
    private JLabel lblTelefono;
    private JLabel lblTarifa;
    private JTextField txtId;
    private JTextField txtEmail;
    private JTextField txtPassword;
    private JTextField txtLegajo;
    private JTextField txtNombre;
    private JTextField txtTelefono;
    private JTextField txtTarifa;

    public PanelFormularioMedicos(Controlador controlador, entidad entidad) {
        super(controlador, entidad);
    }

    @Override
    protected JPanel construirFormulario() {
        JPanel form = new JPanel();
        form.setLayout(new GridLayout(0, 2, 10, 10));

        lblId = UI.crearLabel("ID: ");
        lblEmail = UI.crearLabel("Email: ");
        lblPassword = UI.crearLabel("Password: ");
        lblLegajo = UI.crearLabel("Legajo: ");
        lblNombre = UI.crearLabel("Nombre: ");
        lblTelefono = UI.crearLabel("Telefono: ");
        lblTarifa = UI.crearLabel("Tarifa: ");

        medico doctor = (medico)entidad;

        txtId = UI.construirTextField(String.valueOf(doctor.getId()));
        txtId.setEditable(false);
        txtEmail = UI.construirTextField(doctor.getEmail());
        txtPassword = UI.construirTextField(doctor.getPassword());
        txtLegajo = UI.construirTextField(String.valueOf(doctor.getLegajo()));
        txtNombre = UI.construirTextField(doctor.getNombre());
        txtTelefono = UI.construirTextField(doctor.getTelefono());

        DecimalFormat df = new DecimalFormat("###.00");
        df.setDecimalFormatSymbols(DecimalFormatSymbols.getInstance(Locale.ENGLISH));
        if (doctor.getTarifa() != null) {
            txtTarifa = UI.construirTextField(df.format(doctor.getTarifa()));
        } else {
            txtTarifa = UI.construirTextField(df.format(medico.getTarifaPorDefecto()));
        }

        if (!doctor.isNew()) {
            form.add(lblId);
            form.add(txtId);
        }
        form.add(lblEmail);
        form.add(txtEmail);
        form.add(lblPassword);
        form.add(txtPassword);
        form.add(lblLegajo);
        form.add(txtLegajo);
        form.add(lblNombre);
        form.add(txtNombre);
        form.add(lblTelefono);
        form.add(txtTelefono);
        form.add(lblTarifa);
        form.add(txtTarifa);

        return form;
    }


    protected void accionGuardar(ActionEvent _event) {
        medico doctor = (medico)entidad;
        try {
            doctor.setLegajo(Integer.parseInt(txtLegajo.getText()));
        } catch (NumberFormatException _e) {
            controlador.getFramePrincipal().visualizarError("El DNI es inválido.");
            return;
        }
        doctor.setEmail(txtEmail.getText());
        doctor.setPassword(txtPassword.getText());
        doctor.setNombre(txtNombre.getText());
        doctor.setTelefono(txtTelefono.getText());
        try {
            doctor.setTarifa(new BigDecimal(txtTarifa.getText()));
        } catch (NumberFormatException _e) {
            controlador.getFramePrincipal().visualizarError("La tarifa debe ser un importe válido.");
            return;
        }

        if (doctor.isNew()) {
            if (controlador.insertarEntidad(doctor)) {
                controlador.visualizarDoctores();
            }
        } else {
            if (controlador.modificarEntidad(doctor)) {
                controlador.visualizarDoctores();
            }
        }
    }

    protected void accionCancelar(ActionEvent _event) {
        controlador.visualizarDoctores();
    }

    @Override
    public Class getEntityClass() {
        return medico.class;
    }
}