package ui.administradores;

import Controlador.Controlador;
import Entidades.admin;
import ui.PanelLista;

public class PanelAdministradores extends PanelLista {
    public PanelAdministradores(Controlador controlador) {
        super(controlador);
    }

    @Override
    public Class getEntityClass() {
        return admin.class;
    }
}
