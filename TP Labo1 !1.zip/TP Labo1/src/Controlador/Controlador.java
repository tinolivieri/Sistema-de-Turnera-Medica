package Controlador;

import BO.*;
import DAO.BaseDAO;
import Entidades.*;
import Exceptions.BOException;
import ui.FramePrincipal;
import ui.administradores.PanelAdministradores;
import ui.administradores.PanelFormularioAdministrador;
import ui.medicos.PanelMedicos;
import ui.medicos.PanelFormularioMedicos;
import ui.login.PanelFormularioLogin;
import ui.turnos.PanelFormularioTurno;
import ui.turnos.PanelTurnos;
import javax.swing.*;
import java.util.List;
import java.util.Map;

public class Controlador {
    private FramePrincipal framePrincipal;
    private AdminBO administradorBO;
    private MedicoBO doctorBO;
    private TurnoBO turnoBO;
    private empleado usuario; // Usuario logueado

    public Controlador() {
        administradorBO = new AdminBO();
        doctorBO = new MedicoBO();
        turnoBO = new TurnoBO();
    }

    public void run() {
        SwingUtilities.invokeLater(() -> {
            framePrincipal = new FramePrincipal(this);
            visualizarLogin();
        });
    }

    public FramePrincipal getFramePrincipal() {
        return framePrincipal;
    }

    public <ENTIDAD extends entidad, DAO extends BaseDAO<ENTIDAD>> List<ENTIDAD> getEntidades(BaseBO<ENTIDAD, DAO> bo) {
        try {
            return bo.getAll();
        } catch (BOException e) {
            framePrincipal.visualizarError(e);
            return null;
        }
    }

    public <ENTIDAD extends entidad, DAO extends BaseDAO<ENTIDAD>> List<ENTIDAD> getEntidades(BaseBO<ENTIDAD, DAO> bo, String sortField) {
        try {
            return bo.getAll(sortField);
        } catch (BOException e) {
            framePrincipal.visualizarError(e);
            return null;
        }
    }

    public <ENTIDAD extends entidad, DAO extends BaseDAO<ENTIDAD>> List<ENTIDAD> getEntidades(BaseBO<ENTIDAD, DAO> bo, Map<String, String> conditions) {
        try {
            return bo.getAll(conditions);
        } catch (BOException e) {
            framePrincipal.visualizarError(e);
            return null;
        }
    }

    public <ENTIDAD extends entidad, DAO extends BaseDAO<ENTIDAD>> boolean saveEntidad(BaseBO<ENTIDAD, DAO> bo, ENTIDAD entity, String successMessage) {
        try {
            bo.save(entity);
            framePrincipal.visualizarInformacion(successMessage);
            return true;
        } catch (BOException e) {
            framePrincipal.visualizarError(e);
            return false;
        }
    }

    public <ENTIDAD extends entidad, DAO extends BaseDAO<ENTIDAD>> boolean updateEntidad(BaseBO<ENTIDAD, DAO> bo, ENTIDAD entity, String successMessage) {
        try {
            bo.update(entity);
            framePrincipal.visualizarInformacion(successMessage);
            return true;
        } catch (BOException e) {
            framePrincipal.visualizarError(e);
            return false;
        }
    }

    public <ENTIDAD extends entidad, DAO extends BaseDAO<ENTIDAD>> boolean deleteEntidad(BaseBO<ENTIDAD, DAO> bo, ENTIDAD entity, String confirmMessage, String successMessage) {
        try {
            int opcion = JOptionPane.showConfirmDialog(framePrincipal, confirmMessage + entity.toString() + "?", "Confirmación", JOptionPane.YES_NO_OPTION);
            if (opcion == JOptionPane.YES_OPTION) {
                bo.delete(entity);
                framePrincipal.visualizarInformacion(successMessage);
                return true;
            } else {
                return false;
            }
        } catch (Exception e) {
            framePrincipal.visualizarError(e);
            return false;
        }
    }

    public <T extends entidad> List<T> listarEntidades(Class klass, String sortField) {
        if (klass == admin.class) {
            return (List<T>) getEntidades(administradorBO);
        } else if (klass == medico.class) {
            return (List<T>) getEntidades(doctorBO);
        } else if (klass == turno.class) {
            return (List<T>) getEntidades(turnoBO, sortField);
        }

        return null;
    }

    public <T extends entidad> List<T> listarEntidades(Class klass, entidad filter) {
        // Filtros para doctores

        // Filtro para turnos
        if (klass == turno.class) {
            if (filter.getClass() == medico.class) {
                Map<String, String> conditions = Map.of("doctor_id", Integer.toString(filter.getId()));
                return (List<T>) getEntidades(turnoBO, conditions);
            }
        }
        return null;
    }

    public <T extends entidad> List<T> listarEntidades(Class klass) {
        return listarEntidades(klass, (String) null);
    }

    public boolean insertarEntidad(entidad entidad) {
        if (entidad instanceof admin) {
            return saveEntidad(administradorBO, (admin) entidad, "Se creó el administrador.");
        } else if (entidad instanceof medico) {
            return saveEntidad(doctorBO, (medico) entidad, "Se creó el medico.");
        } else if (entidad instanceof turno) {
            return saveEntidad(turnoBO, (turno) entidad, "Se creó el turno.");
        }
        return false;
    }

    public boolean modificarEntidad(entidad entidad) {
        if (entidad instanceof admin) {
            return updateEntidad(administradorBO, (admin) entidad, "Se modificó el administrador.");
        } else if (entidad instanceof medico) {
            return updateEntidad(doctorBO, (medico) entidad, "Se modificó el doctor.");
        } else if (entidad instanceof turno) {
            return updateEntidad(turnoBO, (turno) entidad, "Se modificó el turno.");
        }
        return false;
    }

    public boolean eliminarEntidad(entidad entidad) {
        if (entidad instanceof admin) {
            return deleteEntidad(administradorBO, (admin) entidad, "Eliminar el administrador ", "Se eliminó el administrador.");
        } else if (entidad instanceof medico) {
            return deleteEntidad(doctorBO, (medico) entidad, "Eliminar el doctor ", "Se eliminó el doctor.");
        } else if (entidad instanceof turno) {
            return deleteEntidad(turnoBO, (turno) entidad, "Eliminar el turno ", "Se eliminó el turno.");
        }
        return false;
    }

    public void panelNuevaEntidad(Class klass) {
        if (klass == admin.class) {
            getFramePrincipal().setPanel(new PanelFormularioAdministrador(this, new admin()));
        } else if (klass == medico.class) {
            getFramePrincipal().setPanel(new PanelFormularioMedicos(this, new medico()));
        } else if (klass == turno.class) {
            getFramePrincipal().setPanel(new PanelFormularioTurno(this, new turno()));
        }
    }

    public void panelModificarEntidad(entidad entidad) {
        if (entidad instanceof admin) {
            getFramePrincipal().setPanel(new PanelFormularioAdministrador(this, (admin) entidad));
        } else if (entidad instanceof medico) {
            getFramePrincipal().setPanel(new PanelFormularioMedicos(this, (medico) entidad));
        } else if (entidad instanceof turno) {
            getFramePrincipal().setPanel(new PanelFormularioTurno(this, (turno) entidad));
        }
    }

    public void visualizarMenuPrincipal() {
        getFramePrincipal().setSize(1920, 1080);
        getFramePrincipal().pantallaPrincipal();
    }

    public void visualizarLogin() {
        framePrincipal.setSize(1920, 150);
        framePrincipal.visualizarPanel(new PanelFormularioLogin(this, null));
    }

    public void visualizarAdministradores() {
        framePrincipal.visualizarPanel(new PanelAdministradores(this));
    }


    public void visualizarDoctores() {
        framePrincipal.visualizarPanel(new PanelMedicos(this));
    }

    public void visualizarTurnos() {
        framePrincipal.visualizarPanel(new PanelTurnos(this));
    }


    public boolean validarLogin(String email, String password) {
        Map<String, String> conditions = Map.of("email", email, "password", password);

        try {
            if (validarLoginHlp(administradorBO, conditions) != null ||
                    validarLoginHlp(doctorBO, conditions) != null) {
                framePrincipal.construirMenu();
                return true;
            }
        } catch (BOException ex) {
            return false;
        }
        return false;
    }

    private empleado validarLoginHlp(BaseBO bo, Map<String, String> conditions) throws BOException {
        empleado usuario = (empleado)bo.getByConditions(conditions);
        if (usuario != null) {
            this.usuario = usuario;
            return usuario;
        }
        return null;
    }

    public empleado getUsuario() {
        return this.usuario;
    }
}