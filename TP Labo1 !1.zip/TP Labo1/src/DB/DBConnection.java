package DB;

import Exceptions.DBException;
import Exceptions.DBExceptionType;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBConnection {
    private static final String DB_DRIVER = "org.h2.Driver";
    private static final String DB_URL = "jdbc:h2:~/turnera";
    private static final String DB_USERNAME = "sa";
    private static final String DB_PASSWORD = "";

    private static DBConnection instance;
    private static Connection connection;

    private DBConnection() throws DBException {
        try {
            Class.forName(DB_DRIVER);
        } catch (ClassNotFoundException e) {
            throw new DBException(DBExceptionType.DRIVER_NOT_FOUND, "Error al registrar el driver de SQL Server: " + e);
        }

        try {
            connection = DriverManager.getConnection(DB_URL, DB_USERNAME, DB_PASSWORD);
            connection.setAutoCommit(false);
        } catch (SQLException ex) {
            throw new DBException(DBExceptionType.CONNECTION_ERROR, "Error al conectar con la base de datos: " + ex);
        }
    }

    public Connection getConnection() {
        return connection;
    }

    public static DBConnection getInstance() throws DBException {
        try {
            if (instance == null) {
                instance = new DBConnection();
            } else if (instance.getConnection().isClosed()) {
                instance = new DBConnection();
            }
        } catch (SQLException ex) {
            throw new DBException(DBExceptionType.CONNECTION_ERROR, "Error al obtener la conexión con la base de datos: " + ex);
        }

        return instance;
    }

    public static void close() throws DBException {
        if (instance == null) {
            return;
        }

        try {
            connection.close();
        } catch (SQLException e) {
            throw new DBException(DBExceptionType.CONNECTION_ERROR, "Error al cerrar la conexión: " + e);
        }
    }
}
