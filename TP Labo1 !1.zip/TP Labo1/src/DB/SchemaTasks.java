package DB;

import BO.*;
import Entidades.*;
import Exceptions.*;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

public class SchemaTasks {
    public void crearTablas() throws DBException {
        Connection c = DBConnection.getInstance().getConnection();
        ArrayList<String> list = new ArrayList<>();
        list.add("""
          CREATE TABLE IF NOT EXISTS doctores(
              id INTEGER AUTO_INCREMENT PRIMARY KEY,
              email VARCHAR(255),
              password VARCHAR(255),
              legajo INTEGER,
              nombre VARCHAR(255),
              telefono VARCHAR(255),
              tarifa numeric,
              UNIQUE (email),
              UNIQUE (legajo)
          )
      """);
        list.add("""
          CREATE TABLE IF NOT EXISTS administradores(
              id INTEGER AUTO_INCREMENT PRIMARY KEY,
              email VARCHAR(255),
              password VARCHAR(255),
              legajo INTEGER,
              nombre VARCHAR(255),
              telefono VARCHAR(255),
              UNIQUE (email),
              UNIQUE (legajo)
          )
      """);

        list.add("""
    CREATE TABLE turnos (
        id INTEGER PRIMARY KEY AUTO_INCREMENT,
        doctor_id INTEGER,
        fecha TIMESTAMP,
        FOREIGN KEY (doctor_id) REFERENCES doctores(id)
    )
""");

        try {
            Statement s = c.createStatement();
            for (String sql : list) {
                s.execute(sql);
            }
        } catch (SQLException ex) {
            try {
                c.rollback();
            } catch (SQLException ex1) {
                throw new DBException(
                        DBExceptionType.TRANSACTION_ERROR,
                        "Error en rollback de creación de las tablas: " + ex1.getMessage()
                );
            }
            throw new DBException(
                    DBExceptionType.TRANSACTION_ERROR,
                    "Error al crear las tablas para correr el sistema: " + ex.getMessage()
            );
        } finally {
            try {
                c.close();
            } catch (SQLException ex) {
                throw new DBException(
                        DBExceptionType.CONNECTION_ERROR,
                        "Error al cerrar la conexión de la base de datos: " + ex.getMessage()
                );
            }
        }
    }

    public void insertarDatosDePrueba() throws DBException, BOException {
        AdminBO administradorBO = new AdminBO();
        MedicoBO doctorBO = new MedicoBO();
        TurnoBO turnoBO = new TurnoBO();

        // Administradores
        administradorBO.save(new admin("admin@gmail.com", "password", 1000, "Admin", "0"));

        // Doctores
        doctorBO.save(new medico("doctor1@gmail.com", "password", 200, "Carlos Rodriguez", "11 1234-5678", new BigDecimal("90.0")));
        doctorBO.save(new medico("doctor2@gmail.com", "password", 201, "Laura Fernández", "11 2345-6789", new BigDecimal("110.0")));
        doctorBO.save(new medico("doctor3@gmail.com", "password", 202, "Javier Martinez", "11 3456-7890", new BigDecimal("95.0")));
        doctorBO.save(new medico("doctor4@gmail.com", "password", 203, "Ana Garcia", "11 4567-8901", new BigDecimal("85.0")));
        doctorBO.save(new medico("doctor5@gmail.com", "password", 204, "Diego Lopez", "11 5678-9012", new BigDecimal("120.0")));


        // Crear turnos para los próximos 60 días
        Random rand = new Random();
        ArrayList<medico> doctores = doctorBO.getAll();
        LocalDateTime fechaLaboral = Util.Dates.getNextWorkDay();
        for (int i = 0; i <= 60; i++) {
            // Crear 10 a 20 turnos por dia
            int cantidadTurnos = rand.nextInt(10) + 10;
            for (int j = 0; j < cantidadTurnos; j++) {
                boolean stored;
                do {
                    // Primero obtener la fecha y hora del turno
                    LocalDateTime fecha = LocalDateTime.from(fechaLaboral.plusDays(i));
                    int hours = rand.nextInt(9) + 9;
                    fecha = fecha.withHour(hours);

                    // Crear el turno con un doctor y paciente aleatorios
                    try {
                        turno turno = new turno();
                        medico medico = doctores.get(rand.nextInt(doctores.size()));
                        turno.setMedico(medico);
                        turno.setFecha(fecha);
                        turnoBO.save(turno);
                        stored = true;
                    } catch (BOException ex) {
                        System.out.println("Turno invalido: " + ex.getMessage());
                        stored = false;
                    }
                } while (!stored);
            }
        }
    }

    public void eliminarTablas() throws DBException {
        Connection c = DBConnection.getInstance().getConnection();
        ArrayList<String> list = new ArrayList<>();
        list.add("DROP TABLE IF EXISTS turnos");
        list.add("DROP TABLE IF EXISTS doctores");
        list.add("DROP TABLE IF EXISTS administradores");

        try {
            Statement s = c.createStatement();
            for (String sql : list) {
                s.execute(sql);
            }
        } catch (SQLException ex) {
            try {
                c.rollback();
            } catch (SQLException ex1) {
                throw new DBException(
                        DBExceptionType.TRANSACTION_ERROR,
                        "Error en rollback de eliminación de las tablas: " + ex1.getMessage()
                );
            }
            throw new DBException(
                    DBExceptionType.TRANSACTION_ERROR,
                    "Error al eliminar las tablas para correr el sistema: " + ex.getMessage()
            );
        } finally {
            try {
                c.close();
            } catch (SQLException ex) {
                throw new DBException(
                        DBExceptionType.CONNECTION_ERROR,
                        "Error al cerrar la conexión de la base de datos: " + ex.getMessage()
                );
            }
        }
    }

    public static void main(String[] args) throws BOException {
        System.out.println("1 - Eliminar,crear tablas e insertar datos de prueba (No Utilizar, codigo roto que no logro reparar)");
        System.out.println("2 - Crear tablas");
        System.out.println("3 - Insertar datos de pruebas");
        System.out.println("4 - Eliminar tablas");
        System.out.print("Seleccione una opcion: ");

        Scanner sc = new Scanner(System.in);
        int opcion = sc.nextInt();

        switch (opcion) {
            case 1:
                System.out.println("Eliminando tablas...");
                (new SchemaTasks()).eliminarTablas();
                System.out.println("Creando tablas...");
                (new SchemaTasks()).crearTablas();
                System.out.println("Insertando datos de prueba...");
                (new SchemaTasks()).insertarDatosDePrueba();
            case 2:
                System.out.println("Creando tablas...");
                (new SchemaTasks()).crearTablas();
                break;
            case 3:
                System.out.println("Insertando datos de prueba...");
                (new SchemaTasks()).insertarDatosDePrueba();
                break;
            case 4:
                System.out.println("Eliminando tablas...");
                (new SchemaTasks()).eliminarTablas();
                break;
        }
    }
}
