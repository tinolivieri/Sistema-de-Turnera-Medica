package Entidades;


public class admin extends empleado implements entidad {
    public admin() {
        super();
    }

    public admin(String email, String password, int legajo, String nombre, String telefono) {
        super(email, password, legajo, nombre, telefono);
    }

    public admin(int id, String email, String password, int legajo, String nombre, String telefono) {
        super(id, email, password, legajo, nombre, telefono);
    }

    @Override
    public int getId() {
        return 0;
    }

    @Override
    public void setId(int id) {

    }

    @Override
    public boolean isNew() {
        return false;
    }

}
