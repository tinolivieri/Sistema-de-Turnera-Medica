package Entidades;

public interface entidad {
    public int getId();

    public void setId(int id);

    public boolean isNew();

    public static String getEntityName() {
        return "Entidad";
    }

    public static String getEntityNamePlural() {
        return "Entidades";
    }
}
