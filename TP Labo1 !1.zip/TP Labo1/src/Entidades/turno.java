package Entidades;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import Util.Dates;

public class turno implements entidad {
    public static final String FORMATO_FECHA = "yyyy/MM/dd HH:mm";

    private medico medico;

    private LocalDateTime fecha;

    private int id;

    public turno() {
    }

    public turno(medico medico, LocalDateTime fecha) {
        this.medico = medico;
        this.fecha = fecha;
    }

    public turno(int id, medico medico, LocalDateTime fecha) {
        this.id = id;
        this.medico = medico;
        this.fecha = fecha;
    }

    public medico getMedico() {
        return medico;
    }

    public void setMedico(medico medico) {
        this.medico = medico;
    }

    public LocalDateTime getFecha() {
        return fecha;
    }

    public void setFecha(LocalDateTime fecha) {
        this.fecha = fecha;
    }

    @Override
    public int getId() {
        return id;
    }

    @Override
    public void setId(int id) {
        this.id = id;
    }

    @Override
    public boolean isNew() {
        return this.id == 0;
    }

    @Override
    public String toString() {
        if (medico != null) {
            return Dates.format(fecha) + " - " + medico.getNombre();
        } else {
            return Dates.format(fecha);
        }
    }

    public BigDecimal getCosto() {
        return new BigDecimal(100);
    }
}
