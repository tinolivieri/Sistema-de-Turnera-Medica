package Entidades;

import java.math.BigDecimal;

public class medico extends empleado implements entidad {
    private BigDecimal tarifa;

    public medico() {
        super();
    }

    public medico(String email, String password, int legajo, String nombre, String telefono, BigDecimal tarifa) {
        super(email, password, legajo, nombre, telefono);
        this.tarifa = tarifa;
    }

    public medico(int id, String email, String password, int legajo, String nombre, String telefono, BigDecimal tarifa) {
        super(id, email, password, legajo, nombre, telefono);
        this.tarifa = tarifa;
    }

    public BigDecimal getTarifa() {
        return tarifa;
    }

    public void setTarifa(BigDecimal tarifa) {
        this.tarifa = tarifa;
    }

    public static BigDecimal getTarifaPorDefecto() {
        return new BigDecimal(100.0);
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }

        if (!(other instanceof medico)) {
            return false;
        }

        return ((medico) other).getId() == this.getId();
    }

}
