package Util;

import javax.swing.*;

public class UI {
    public static JLabel crearLabel(String texto) {
        JLabel label = new JLabel(texto);
        label.setHorizontalAlignment(JLabel.CENTER);
        return label;
    }

    public static JTextField construirTextField(String texto) {
        JTextField textField = new JTextField();
        textField.setText(texto);
        return textField;
    }
}
