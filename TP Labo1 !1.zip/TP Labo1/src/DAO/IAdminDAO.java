package DAO;

import Entidades.admin;
import Exceptions.DBException;

public interface IAdminDAO extends IBaseDAO<admin> {
    admin getByLegajo(int legajo) throws DBException;
}
