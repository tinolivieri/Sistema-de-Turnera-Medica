package DAO;

import Entidades.medico;
import Entidades.turno;
import Exceptions.DBException;
import Exceptions.DBExceptionType;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Map;

public class TurnoDAO extends BaseDAO<turno> implements ITurnoDAO {
    @Override
    protected String getEntidad() {
        return "turnos";
    }


    MedicoDAO medicoDAO;

    public TurnoDAO() {
        this.medicoDAO = new MedicoDAO();
    }

    @Override
    protected String saveSQL(turno turno) {
        return "INSERT INTO turnos (doctor_id, fecha) VALUES (" +
                turno.getMedico().getId() + ", '" +
                turno.getFecha().toString() + "')";
    }


    @Override
    protected String updateSQL(turno turno) {
        return "UPDATE turnos set doctor_id = " + turno.getMedico().getId() +
                ", fecha = '" + turno.getFecha() +
                "' WHERE id = " + turno.getId();
    }

    protected turno objectFromRS(ResultSet rs) throws DBException {
        try {
            return new turno(
                    rs.getInt("id"),
                    medicoDAO.get(rs.getInt("doctor_id")),
                    rs.getTimestamp("fecha").toLocalDateTime()
            );
        } catch (SQLException ex) {
            throw new DBException(DBExceptionType.QUERY_ERROR, ex.getMessage());
        }
    }

    public turno getByMedicoFecha(int doctorId, LocalDateTime fecha) throws DBException {
        Map params = Map.of("doctor_id", Integer.toString(doctorId), "fecha", fecha.toString());
        return getByField(params);
    }
    @Override
    public ArrayList<turno> getAllBetweenDates(medico medico, LocalDateTime desde, LocalDateTime hasta) throws DBException {
        String sql = "SELECT * FROM turnos WHERE doctor_id = " + medico.getId() + " AND fecha BETWEEN '" + desde + "' AND '" + hasta + "'";
        return fetchAllByQuery(sql);
    }
}

