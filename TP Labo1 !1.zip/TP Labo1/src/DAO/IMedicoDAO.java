package DAO;

import Entidades.medico;
import Exceptions.DBException;

public interface IMedicoDAO extends IBaseDAO<medico> {
    medico getByLegajo(int legajo) throws DBException;
}