package DAO;

import Entidades.medico;
import Entidades.turno;
import Exceptions.DBException;

import java.time.LocalDateTime;
import java.util.ArrayList;


public interface ITurnoDAO extends IBaseDAO<turno> {
    turno getByMedicoFecha(int id, LocalDateTime fecha) throws DBException;
    ArrayList<turno> getAllBetweenDates(medico medico, LocalDateTime desde, LocalDateTime hasta) throws DBException;
}