package DAO;

import Entidades.medico;
import Exceptions.DBException;
import Exceptions.DBExceptionType;
import java.sql.ResultSet;
import java.sql.SQLException;

public class MedicoDAO extends BaseDAO<medico> implements IMedicoDAO {
    @Override
    protected String getEntidad() {
        return "doctores";
    }

    @Override
    protected String saveSQL(medico medico) {
        return "INSERT INTO doctores (email, password, legajo, nombre, telefono, tarifa) VALUES ('" +
                medico.getEmail() + "', '" +
                medico.getPassword() + "', " +
                medico.getLegajo() + ", '" +
                medico.getNombre() + "', '" +
                medico.getTelefono() + "', " +
                medico.getTarifa() +")";
    }

    @Override
    protected String updateSQL(medico medico) {
        return "UPDATE doctores set email = '" + medico.getEmail() +
                "', password = '" + medico.getPassword() +
                "', legajo = " + medico.getLegajo() +
                ", nombre = '" + medico.getNombre() +
                "', telefono = '" + medico.getTelefono() +
                ", tarifa = " + medico.getTarifa() +
                " WHERE id = " + medico.getId();
    }

    public medico getByLegajo(int legajo) throws DBException {
        return getByField("legajo", String.valueOf(legajo));
    }

    protected medico objectFromRS(ResultSet rs) throws DBException {
        try {
            return new medico(
                    rs.getInt("id"),
                    rs.getString("email"),
                    rs.getString("password"),
                    rs.getInt("legajo"),
                    rs.getString("nombre"),
                    rs.getString("telefono"),
                    rs.getBigDecimal("tarifa")
            );
        } catch (SQLException ex) {
            throw new DBException(DBExceptionType.QUERY_ERROR, ex.getMessage());
        }
    }
}
