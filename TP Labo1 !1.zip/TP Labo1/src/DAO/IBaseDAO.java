package DAO;

import Entidades.entidad;
import Exceptions.DBException;

import java.util.ArrayList;
import java.util.Map;

public interface IBaseDAO<T extends entidad> {
    T get(int id) throws DBException;

    ArrayList<T> getAll() throws DBException;

    ArrayList<T> getAll(String sortField) throws DBException;

    ArrayList<T> getAll(Map<String, String> fields) throws DBException;

    T save(T t) throws DBException;

    T update(T t) throws DBException;

    void delete(T t) throws DBException;
}
