package DAO;

import DB.DBConnection;
import Entidades.entidad;
import Exceptions.DBException;
import Exceptions.DBExceptionType;

import java.sql.*;
import java.util.*;


public abstract class BaseDAO<T extends entidad> implements IBaseDAO<T> {

    protected abstract String getEntidad();

    protected String selectById(int id) {
        return "SELECT * FROM " + getEntidad() + " WHERE id = '" + id + "'";
    }

    protected String selectAll() {
        return "SELECT * FROM " + getEntidad();
    }

    protected String selectAll(String sortField) {
        return "SELECT * FROM " + getEntidad() + " ORDER BY " + sortField;
    }

    protected abstract String saveSQL(T t);

    protected abstract String updateSQL(T t);

    protected String deleteSQL(T t) {
        return "DELETE FROM " + getEntidad() + " WHERE id = " + t.getId();
    }

    protected abstract T objectFromRS(ResultSet rs) throws DBException;

    @Override
    public T get(int id) throws DBException {
        String sql = this.selectById(id);

        Connection connection = DBConnection.getInstance().getConnection();
        T entidad = null;
        try {
            Statement stmt = connection.createStatement();
            ResultSet rs = stmt.executeQuery(sql);

            if (rs.next()) {
                entidad = objectFromRS(rs);
            }
        } catch (SQLException ex) {
            try {
                connection.rollback();
            } catch (SQLException exx) {
            }
            throw new DBException(DBExceptionType.QUERY_ERROR, ex.getMessage());
        }

        return entidad;
    }

    @Override
    public ArrayList<T> getAll() throws DBException {
        String sql = this.selectAll();
        return fetchAllByQuery(sql);
    }

    @Override
    public ArrayList<T> getAll(String sortField) throws DBException {
        String sql = this.selectAll(sortField);
        return fetchAllByQuery(sql);
    }

    @Override
    public ArrayList<T> getAll(Map<String, String> fields) throws DBException {
        String sql = this.selectAll();

        if (fields != null) {
            sql += " WHERE ";
            for (Map.Entry<String,String> entry : fields.entrySet()) {
                sql += entry.getKey() + " = '" + entry.getValue() + "' AND ";
            }
            sql = sql.substring(0, sql.length() - 5);
        }

        return fetchAllByQuery(sql);
    }

    @Override
    public T save(T entidad) throws DBException {
        String sql = saveSQL(entidad);
        return store(sql);
    }

    @Override
    public T update(T entidad) throws DBException {
        String sql = updateSQL(entidad);
        return store(sql);
    }

    protected T store(String sql) throws DBException {
        Connection connection = DBConnection.getInstance().getConnection();
        try {
            PreparedStatement stmt = connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
            stmt.executeUpdate();
            connection.commit();
            ResultSet generatedKeys = stmt.getGeneratedKeys();
            if (generatedKeys.next()) {
                int key = generatedKeys.getInt(1);
                return get(key);
            }
            return null;
        } catch (SQLException ex) {
            try {
                connection.rollback();
            } catch (SQLException exx) {
            }
            throw new DBException(DBExceptionType.TRANSACTION_ERROR, ex.getMessage());
        }
    }

    @Override
    public void delete(T entidad) throws DBException {
        String sql = deleteSQL(entidad);

        Connection connection = DBConnection.getInstance().getConnection();
        try {
            Statement stmt = connection.createStatement();
            stmt.executeUpdate(sql);
            connection.commit();
        } catch (SQLException ex) {
            try {
                connection.rollback();
            } catch (SQLException exx) {
            }
            throw new DBException(DBExceptionType.TRANSACTION_ERROR, ex.getMessage());
        }
    }

    public T getByField(String field, String value) throws DBException {
        String sql = "SELECT * FROM " + this.getEntidad() + " WHERE " + field + " = '" + value + "'";

        return fetchOneByQuery(sql);
    }

    public T getByField(Map<String, String> fields) throws DBException {
        String sql = "SELECT * FROM " + this.getEntidad() + " WHERE ";
        for (Map.Entry<String,String> entry : fields.entrySet()) {
            sql += entry.getKey() + " = '" + entry.getValue() + "' AND ";
        }
        sql = sql.substring(0, sql.length() - 5);

        return fetchOneByQuery(sql);
    }

    protected T fetchOneByQuery(String sql) {
        Connection connection = DBConnection.getInstance().getConnection();
        T entidad = null;
        try {
            Statement stmt = connection.createStatement();
            ResultSet rs = stmt.executeQuery(sql);

            if (rs.next()) {
                entidad = objectFromRS(rs);
            }
        } catch (SQLException ex) {
            try {
                connection.rollback();
            } catch (SQLException exx) {
            }
            throw new DBException(DBExceptionType.QUERY_ERROR, ex.getMessage());
        }

        return entidad;
    }

    protected ArrayList<T> fetchAllByQuery(String sql) {
        Connection connection = DBConnection.getInstance().getConnection();
        ArrayList<T> lista = new ArrayList<>();
        try {
            Statement stmt = connection.createStatement();
            ResultSet rs = stmt.executeQuery(sql);

            while (rs.next()) {
                lista.add(objectFromRS(rs));
            }
        } catch (SQLException ex) {
            try {
                connection.rollback();
            } catch (SQLException exx) {
            }
            throw new DBException(DBExceptionType.QUERY_ERROR, ex.getMessage());
        }

        return lista;
    }
}
