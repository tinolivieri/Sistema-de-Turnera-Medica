package DAO;

import Entidades.admin;
import Exceptions.DBException;
import Exceptions.DBExceptionType;

import java.sql.ResultSet;
import java.sql.SQLException;

public class AdminDAO extends BaseDAO<admin> implements IAdminDAO {
    @Override
    protected String getEntidad() {
        return "administradores";
    }

    public AdminDAO() {
    }

    @Override
    protected String saveSQL(admin admin) {
        return "INSERT INTO administradores (email, password, legajo, nombre, telefono) VALUES ('" +
                admin.getEmail() + "', '" +
                admin.getPassword() + "', '" +
                admin.getLegajo() + "', '" +
                admin.getNombre() + "', '" +
                admin.getTelefono() + "')";
    }

    @Override
    protected String updateSQL(admin admin) {
        return "UPDATE administradores set email = '" + admin.getEmail() +
                "', password = '" + admin.getPassword() +
                "', legajo = '" + admin.getLegajo() +
                "', nombre = '" + admin.getNombre() +
                "', telefono = '" + admin.getTelefono() +
                "' WHERE id = " + admin.getId();
    }

    public admin getByLegajo(int legajo) throws DBException {
        return getByField("legajo", String.valueOf(legajo));
    }


    protected admin objectFromRS(ResultSet rs) throws DBException {
        try {
            return new admin(
                    rs.getInt("id"),
                    rs.getString("email"),
                    rs.getString("password"),
                    rs.getInt("legajo"),
                    rs.getString("nombre"),
                    rs.getString("telefono")
            );
        } catch (SQLException ex) {
            throw new DBException(DBExceptionType.QUERY_ERROR, ex.getMessage());
        }
    }
}
