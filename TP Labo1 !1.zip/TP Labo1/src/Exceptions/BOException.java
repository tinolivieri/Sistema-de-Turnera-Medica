package Exceptions;


import java.util.List;

public class BOException extends Exception {
    public BOException() {
        super();
    }

    public BOException(String message) {
        super(message);
    }

    public BOException(List<String> errores) {
        super(String.join("\n", errores));
    }
}