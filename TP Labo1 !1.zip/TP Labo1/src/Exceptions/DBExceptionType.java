package Exceptions;

public enum DBExceptionType {
    DRIVER_NOT_FOUND,
    CONNECTION_ERROR,
    QUERY_ERROR,
    TRANSACTION_ERROR,
}