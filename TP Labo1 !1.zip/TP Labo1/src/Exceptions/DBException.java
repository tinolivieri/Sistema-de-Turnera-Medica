package Exceptions;

public class DBException extends RuntimeException {
    private DBExceptionType type;

    public DBException(DBExceptionType type, String message) {
        super(message);
        this.type = type;
    }

    public DBExceptionType getType() {
        return type;
    }

    public void setType(DBExceptionType type) {
        this.type = type;
    }
}

