package BO;

import DAO.AdminDAO;
import Entidades.admin;
import Exceptions.BOException;
import Exceptions.DBException;
import validations.StringValidations;

import java.util.ArrayList;

public class AdminBO extends BaseBO<admin, AdminDAO> {
    public AdminBO() {
        super(new AdminDAO());
    }

    @Override
    public void validar(admin entidad) throws BOException {
        ArrayList<String> errores = new ArrayList<>();

        if (StringValidations.isEmpty(entidad.getEmail())) {
            errores.add("El email no puede estar vacío");
        } else if (!StringValidations.validEmail(entidad.getEmail())) {
            errores.add("El email es inválido");
        }

        if (StringValidations.isEmpty(entidad.getPassword())) {
            errores.add("El password no puede estar vacío");
        }

        if (existeLegajo(entidad)) {
            errores.add("Ya existe un administrador con el legajo " + entidad.getLegajo());
        }

        if (StringValidations.isEmpty(entidad.getNombre())) {
            errores.add("El nombre no puede estar vacío");
        }

        if (StringValidations.isEmpty(entidad.getTelefono())) {
            errores.add("El teléfono no puede estar vacío");
        }

        if (!errores.isEmpty()) {
            throw new BOException(errores);
        }
    }

    private boolean existeLegajo(admin entidad) {
        try {
            admin otro = dao.getByLegajo(entidad.getLegajo());
            if (otro != null && otro.getId() != entidad.getId()) {
                return true;
            }
        } catch (DBException ignored) {
        }
        return false;
    }

    /**
     * Elimina un administrador, a no ser que sea el unico administrador en la base de datos
     *
     * @param entidad Entidad a eliminar
     */
    public void delete(admin entidad) throws BOException {
        try {
            if (getAll().size() == 1) {
                throw new BOException("No se puede eliminar el único administrador");
            }
            dao.delete(entidad);
        } catch (DBException e) {
            throw new BOException("Error al eliminar la entidad en la base de datos: " + e.getMessage());
        }
    }
}
