package BO;

import DAO.BaseDAO;
import Entidades.entidad;
import Exceptions.DBException;
import Exceptions.BOException;

import java.util.ArrayList;
import java.util.Map;

public abstract class BaseBO<ENTIDAD extends entidad, DAO extends BaseDAO<ENTIDAD>> {
    protected DAO dao;

    public BaseBO(DAO dao) {
        this.dao = dao;
    }

    public ENTIDAD save(ENTIDAD entidad) throws BOException {
        validar(entidad);
        try {
            return dao.save(entidad);
        } catch (Exception ex) {
            throw new BOException("Error al insertar la entidad en la base de datos: " + ex.getMessage());
        }
    }
    public ENTIDAD update(ENTIDAD entidad) throws BOException {
        validar(entidad);
        try {
            return dao.update(entidad);
        } catch (DBException e) {
            throw new BOException("Error al insertar la entidad en la base de datos: " + e.getMessage());
        }
    }

    public void delete(ENTIDAD entidad) throws BOException {
        try {
            dao.delete(entidad);
        } catch (DBException e) {
            throw new BOException("Error al eliminar la entidad en la base de datos: " + e.getMessage());
        }
    }

    public ENTIDAD getByConditions(Map<String, String> conditions) throws BOException {
        try {
            return dao.getByField(conditions);
        } catch (DBException e) {
            throw new BOException("Error al obtener la entidad de base de datos: " + e.getMessage());
        }
    }

    public ArrayList<ENTIDAD> getAll() throws BOException {
        try {
            return dao.getAll();
        } catch (DBException e) {
            throw new BOException("Error al obtener las entidades de base de datos: " + e.getMessage());
        }
    }

    public ArrayList<ENTIDAD> getAll(String sortField) throws BOException {
        try {
            return dao.getAll(sortField);
        } catch (DBException e) {
            throw new BOException("Error al obtener las entidades de base de datos: " + e.getMessage());
        }
    }

    public ArrayList<ENTIDAD> getAll(Map<String, String> conditions) throws BOException {
        try {
            return dao.getAll(conditions);
        } catch (DBException e) {
            throw new BOException("Error al obtener las entidades de base de datos: " + e.getMessage());
        }
    }

    public abstract void validar(ENTIDAD entidad) throws BOException;
}
