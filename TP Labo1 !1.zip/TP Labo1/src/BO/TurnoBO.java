package BO;

import DAO.TurnoDAO;
import Entidades.turno;
import Exceptions.BOException;
import java.util.ArrayList;

public class TurnoBO extends BaseBO<turno, TurnoDAO> {
    public TurnoBO() {
        super(new TurnoDAO());
    }
    public void validar(turno entidad) throws BOException {
        ArrayList<String> errores = new ArrayList<>();

        if (entidad.getMedico() == null) {
            errores.add("El turno debe tener un medico");
        }

        if (entidad.getMedico() != null) {
            turno otro = dao.getByMedicoFecha(entidad.getMedico().getId(), entidad.getFecha());
            if (otro != null && otro.getId() != entidad.getId()) {
                errores.add("El doctor ya tiene un turno asignado para la fecha " + entidad.getFecha());
            }
        }

        if (!errores.isEmpty()) {
            throw new BOException(errores);
        }
    }
    }
